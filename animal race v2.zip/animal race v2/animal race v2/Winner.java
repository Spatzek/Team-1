import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Winner here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Winner extends Actor
{
    public Winner()
    {
        setImage(new GreenfootImage ("Winner", 48, Color.BLACK, Color.WHITE));
    }
}
